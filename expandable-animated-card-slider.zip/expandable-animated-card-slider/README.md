# Expandable Animated Card Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/yudizsolutions/pen/wvzrPoj](https://codepen.io/yudizsolutions/pen/wvzrPoj).

We have made an expandable animated card slider, it will expand and collapse based on card click. We used owl carousel and jQuery for variable width and responsive slider. 

Made by Rajnee Makwana from Yudiz